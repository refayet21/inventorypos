String currency = '\$';
String currencyName = 'United States Dollar';
List<String> items = ['৳ (Taka)', '\$ (US Dollar)', "₹ (Rupee)", "€ (Euro)", "₽ (Ruble)", "£ (UK Pound)", "R (Rial)", "؋ Af ⁄ Afs"];
